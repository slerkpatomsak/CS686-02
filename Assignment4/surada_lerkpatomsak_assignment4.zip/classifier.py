class classifier:

    def __init__(self):
        pass

    def fit(self, X, Y):
        pass

    def predict(self, X):
        pass

